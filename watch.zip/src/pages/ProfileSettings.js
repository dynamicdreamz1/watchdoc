import React from 'react'
import ProfileSettingTabs from '../components/Clinician/Profile/ProfileSettingTabs'

export default function ProfileSettings() {
  return (
    <>
      <ProfileSettingTabs/>
    </>
  )
}
