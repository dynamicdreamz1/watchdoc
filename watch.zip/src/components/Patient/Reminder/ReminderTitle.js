import React from 'react'

export default function ReminderTitle() {
  return (
    <>
    <div className='r-title'>
        <h4>Weigh In</h4>
    </div>
    </>
  )
}
