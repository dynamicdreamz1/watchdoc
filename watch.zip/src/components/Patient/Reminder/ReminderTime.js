import React from 'react'

export default function ReminderTime() {
  return (
    <>
    <div className='reminder-date'>
        <span>Time: 9:30 am</span>
    </div>
    </>
  )
}
