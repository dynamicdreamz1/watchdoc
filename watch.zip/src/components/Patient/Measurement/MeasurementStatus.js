import React from 'react'

export default function MeasurementStatus(props) {

  return (
    <>
    <div className= {`${props.status} m-status alert`}>
    </div>
    </>
  )
}
