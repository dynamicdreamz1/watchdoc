import React from 'react'
import {GetdayHourMin} from "../../../Utility/functions"

export default function MeasurementLastRecording(props) {
  const {latest}=props?.data
  const  date = GetdayHourMin(latest?.[props?.result]?.date)
// console.log("latest?.[props?.result]?.count",latest?.[props?.result]?.date);
  return (
    <>
    <div className='mlr'>
        <span className='text'>Last recording</span>
        <span className='time'>{props.time}</span>
    </div>
    </>
  )
}
