import React from 'react'

export default function Email({ email }) {

  return (
    <>
      <div className='email'><span>{email}</span></div>
    </>
  )
}
