import React from 'react'
import Stack from '@mui/material/Stack';

export default function TablePagination() {
  return (
    <>
        <Stack spacing={2} className="table-pagination">
            
        </Stack>
    </>
  )
}
