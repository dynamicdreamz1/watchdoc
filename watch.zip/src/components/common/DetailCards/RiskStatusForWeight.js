
import React from 'react'

export default function RiskStatusForWeight() {
  return (
    <>
    <div className='r-status d-flex align-items-center'>
       {/* {el?.status && <span className='icon'></span>} */}
        <span className='text'>normal</span>
    </div>
    </>
  )
}
